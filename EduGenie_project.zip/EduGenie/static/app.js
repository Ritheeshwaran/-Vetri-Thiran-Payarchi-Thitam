const task = document.getElementById("task");
const inputText = document.getElementById("inputText");
const inputLabel = document.getElementById("inputLabel");
const taskForm = document.getElementById("taskForm");
const result = document.getElementById("result");
const submitButton = document.getElementById("submitButton");
const clearButton = document.getElementById("clearButton");
const copyButton = document.getElementById("copyButton");
const statusBadge = document.getElementById("statusBadge");

const config = {
    qa: {
        label: "Your question",
        placeholder: "Example: What is the difference between RAM and ROM?",
        button: "Get Answer",
    },
    explain: {
        label: "Topic to explain",
        placeholder: "Example: Explain binary search to a beginner.",
        button: "Explain",
    },
    quiz: {
        label: "Topic or passage for the quiz",
        placeholder: "Paste a passage or enter a topic such as Pythagoras theorem.",
        button: "Generate Quiz",
    },
    summarize: {
        label: "Text to summarize",
        placeholder: "Paste your lecture notes or educational passage here.",
        button: "Summarize",
    },
    learn: {
        label: "Topic to learn",
        placeholder: "Example: SQL, Python, Data Structures, Machine Learning",
        button: "Get Recommendations",
    },
};

function setResult(message, isError = false) {
    result.classList.remove("empty", "error");
    if (isError) result.classList.add("error");
    result.textContent = message;
    copyButton.disabled = false;
}

function setLoading(loading) {
    submitButton.disabled = loading;
    task.disabled = loading;
    inputText.disabled = loading;
    submitButton.textContent = loading ? "Thinking…" : config[task.value].button;
}

function updateForm() {
    const current = config[task.value];
    inputLabel.textContent = current.label;
    inputText.placeholder = current.placeholder;
    submitButton.textContent = current.button;
    inputText.value = "";
    result.className = "result empty";
    result.textContent = "Your AI-generated result will appear here.";
    copyButton.disabled = true;
}

function renderMarkdownish(text) {
    const escaped = text
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");

    return escaped
        .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
        .replace(/^### (.*)$/gm, "<h4>$1</h4>")
        .replace(/^## (.*)$/gm, "<h3>$1</h3>")
        .replace(/^# (.*)$/gm, "<h3>$1</h3>")
        .replace(/^- (.*)$/gm, "• $1")
        .replace(/\n/g, "<br>");
}

function renderQuiz(questions) {
    result.className = "result quiz-result";
    result.innerHTML = "";

    questions.forEach((item, index) => {
        const block = document.createElement("div");
        block.className = "quiz-question";

        const title = document.createElement("h3");
        title.textContent = `Q${index + 1}. ${item.question}`;
        block.appendChild(title);

        const options = document.createElement("div");
        options.className = "options";

        item.options.forEach((option) => {
            const label = document.createElement("label");
            label.className = "option";
            label.innerHTML = `
                <input type="radio" name="q${index}" value="${escapeHtml(option)}">
                <span>${escapeHtml(option)}</span>
            `;
            options.appendChild(label);
        });

        const check = document.createElement("button");
        check.type = "button";
        check.className = "check-answer";
        check.textContent = "Check Answer";

        const feedback = document.createElement("p");
        feedback.className = "feedback";

        check.addEventListener("click", () => {
            const selected = block.querySelector(`input[name="q${index}"]:checked`);
            if (!selected) {
                feedback.textContent = "Please select an option.";
                feedback.className = "feedback error-text";
                return;
            }

            if (selected.value === item.answer) {
                feedback.textContent = "✓ Correct!";
                feedback.className = "feedback correct";
            } else {
                feedback.textContent = `✗ Incorrect. Correct answer: ${item.answer}`;
                feedback.className = "feedback error-text";
            }
        });

        block.appendChild(options);
        block.appendChild(check);
        block.appendChild(feedback);
        result.appendChild(block);
    });
}

function escapeHtml(value) {
    return value.replace(/[&<>"']/g, (char) => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#039;",
    }[char]));
}

async function submitTask(event) {
    event.preventDefault();

    const value = inputText.value.trim();
    if (!value) {
        setResult("Please enter something first.", true);
        return;
    }

    setLoading(true);
    setResult("EduGenie is generating your result…");

    try {
        let response;
        const selected = task.value;

        if (selected === "qa") {
            response = await fetch(`/qa?question=${encodeURIComponent(value)}`);
        } else if (selected === "explain") {
            response = await fetch("/explain", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ topic: value }),
            });
        } else if (selected === "quiz") {
            response = await fetch("/quiz", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ text: value }),
            });
        } else if (selected === "summarize") {
            response = await fetch("/summarize", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ text: value }),
            });
        } else {
            response = await fetch(
                `/learn/recommendations?topic=${encodeURIComponent(value)}`
            );
        }

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.detail || "The server returned an error.");
        }

        if (selected === "qa") {
            result.innerHTML = `<h3>Answer</h3><p>${renderMarkdownish(data.answer)}</p>`;
        } else if (selected === "explain") {
            result.innerHTML = `<h3>Explanation</h3><p>${renderMarkdownish(data.explanation)}</p>`;
        } else if (selected === "summarize") {
            result.innerHTML = `<h3>Summary</h3><p>${renderMarkdownish(data.summary)}</p>`;
        } else if (selected === "learn") {
            result.innerHTML = `<h3>Learning Path</h3><p>${renderMarkdownish(data.recommendation)}</p>`;
        } else {
            renderQuiz(data.quiz);
        }

        result.classList.remove("empty");
        copyButton.disabled = false;
    } catch (error) {
        setResult(error.message || "Something went wrong.", true);
    } finally {
        setLoading(false);
    }
}

task.addEventListener("change", updateForm);
taskForm.addEventListener("submit", submitTask);

clearButton.addEventListener("click", () => {
    inputText.value = "";
    result.className = "result empty";
    result.textContent = "Your AI-generated result will appear here.";
    copyButton.disabled = true;
});

copyButton.addEventListener("click", async () => {
    try {
        await navigator.clipboard.writeText(result.innerText);
        copyButton.textContent = "Copied!";
        setTimeout(() => (copyButton.textContent = "Copy"), 1200);
    } catch {
        copyButton.textContent = "Copy failed";
    }
});

async function checkHealth() {
    try {
        const response = await fetch("/health");
        const data = await response.json();
        if (data.gemini_configured || data.explanation_provider === "local") {
            statusBadge.textContent = "API ready";
            statusBadge.className = "status ready";
        } else {
            statusBadge.textContent = "Add API key";
            statusBadge.className = "status warning";
        }
    } catch {
        statusBadge.textContent = "Server unavailable";
        statusBadge.className = "status error";
    }
}

updateForm();
checkHealth();
