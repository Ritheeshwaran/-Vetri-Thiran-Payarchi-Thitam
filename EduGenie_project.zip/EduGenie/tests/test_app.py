from fastapi.testclient import TestClient
from unittest.mock import patch

from main import app

client = TestClient(app)


def test_home_page():
    response = client.get("/")
    assert response.status_code == 200
    assert "EduGenie" in response.text


def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


@patch("main.answer_question", return_value="The Pacific Ocean is the largest ocean.")
def test_qa_endpoint(mock_answer):
    response = client.get("/qa", params={"question": "Which is the largest ocean?"})
    assert response.status_code == 200
    assert response.json()["answer"].startswith("The Pacific")
    mock_answer.assert_called_once()


@patch("main.explain_topic", return_value="Binary search repeatedly halves a sorted search space.")
def test_explain_endpoint(mock_explain):
    response = client.post("/explain", json={"topic": "binary search"})
    assert response.status_code == 200
    assert "Binary search" in response.json()["explanation"]


@patch("main.summarize_text", return_value="A short summary.")
def test_summary_endpoint(mock_summary):
    response = client.post(
        "/summarize",
        json={"text": "This is an educational paragraph containing enough text to pass validation."},
    )
    assert response.status_code == 200
    assert response.json()["summary"] == "A short summary."


@patch(
    "main.generate_quiz",
    return_value=[
        {
            "question": "2 + 2 = ?",
            "options": ["1", "2", "3", "4"],
            "answer": "4",
        },
        {
            "question": "3 + 3 = ?",
            "options": ["4", "5", "6", "7"],
            "answer": "6",
        },
        {
            "question": "5 + 5 = ?",
            "options": ["8", "9", "10", "11"],
            "answer": "10",
        },
    ],
)
def test_quiz_endpoint(mock_quiz):
    response = client.post(
        "/quiz",
        json={"text": "Generate a simple mathematics quiz from this passage."},
    )
    assert response.status_code == 200
    assert len(response.json()["quiz"]) == 3


@patch("main.get_learning_recommendations", return_value="Beginner -> Intermediate -> Advanced")
def test_learning_path_endpoint(mock_learning):
    response = client.get("/learn/recommendations", params={"topic": "SQL"})
    assert response.status_code == 200
    assert "Beginner" in response.json()["recommendation"]
